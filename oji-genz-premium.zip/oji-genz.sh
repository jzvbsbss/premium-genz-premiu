#!/bin/bash
# OJI-GENZ SYSTEM PREMIUM v2 + DDOS UPDATE
# (Isi script kamu panjang tadi, saya masukkan di sini kalau mau lengkap.)
